using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor FRoller;
extern motor BRoller;
extern motor IntakeRight;
extern motor IntakeLeft;
extern motor BLMotor;
extern motor FLMotor;
extern motor BRMotor;
extern motor FRMotor;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );