/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Student                                          */
/*    Created:      Thu Oct 22 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/
// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// mClaw                motor         16              
// IntakeRight          motor         9               
// IntakeLeft           motor         10              
// BLMotor              motor         6               
// FLMotor              motor         3               
// BRMotor              motor         5               
// FRMotor              motor         4               
// Vision               vision        19              
// Inertial             inertial      11              
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "vex.h"
using namespace vex;


void Forward(double distance, int vel) {
  BLMotor.setPosition(0,degrees);
  BLMotor.setVelocity(vel, percent);

  FLMotor.setVelocity(vel, percent);

  BRMotor.setVelocity(vel, percent);

  FRMotor.setVelocity(vel, percent);

  BLMotor.spin(forward);

  FLMotor.spin(forward);

  BRMotor.spin(forward);

  FRMotor.spin(forward);

  waitUntil(BLMotor.position(degrees) >= distance);
  {

    BLMotor.stop();

    FLMotor.stop();

    BRMotor.stop();

    FRMotor.stop();
    BLMotor.setPosition(0,degrees);
    vex::this_thread::sleep_for(100);
  }
}

void Backwards(double distance, int vel) {
  BLMotor.setPosition(0,degrees);
  BLMotor.setVelocity(vel, percent);

  FLMotor.setVelocity(vel, percent);

  BRMotor.setVelocity(vel, percent);

  FRMotor.setVelocity(vel, percent);

  BLMotor.spin(reverse);

  FLMotor.spin(reverse);

  BRMotor.spin(reverse);

  FRMotor.spin(reverse);
  
  waitUntil(BLMotor.position(degrees) <= -distance);
  {

    BLMotor.stop();

    FLMotor.stop();

    BRMotor.stop();

    FRMotor.stop();
    BLMotor.setPosition(0,degrees);
    vex::this_thread::sleep_for(100);
  }
}

void Left(double distance, int vel) {
  FRMotor.setPosition(0,degrees);
  BLMotor.setVelocity(vel, percent);

  FLMotor.setVelocity(vel, percent);

  BRMotor.setVelocity(vel, percent);

  FRMotor.setVelocity(vel, percent);

  BLMotor.spin(reverse);

  FLMotor.spin(reverse);

  BRMotor.spin(forward);

  FRMotor.spin(forward);

  waitUntil(FRMotor.position(degrees) >= distance);
  {

    BLMotor.stop();

    FLMotor.stop();

    BRMotor.stop();

    FRMotor.stop();
    FRMotor.setPosition(0,degrees);
    vex::this_thread::sleep_for(200);
  }
}

void Right(double distance, int vel) {
  BRMotor.setPosition(0,degrees);
  BLMotor.setVelocity(vel, percent);

  FLMotor.setVelocity(vel, percent);

  BRMotor.setVelocity(vel, percent);

  FRMotor.setVelocity(vel, percent);

  BLMotor.spin(forward);

  FLMotor.spin(forward);

  BRMotor.spin(reverse);

  FRMotor.spin(reverse);

  {
  waitUntil(BRMotor.position(degrees)<=-distance);
    BLMotor.stop();

    FLMotor.stop();

    BRMotor.stop();

    FRMotor.stop();
    BRMotor.setPosition(0,degrees);
    vex::this_thread::sleep_for(100);
  }
}

void inTake(double dgrs) {

  IntakeLeft.setStopping(hold);

  IntakeRight.setStopping(hold);

  IntakeLeft.spin(forward);

  IntakeRight.spin(forward);

  waitUntil(IntakeLeft.position(degrees) == dgrs ||
            IntakeLeft.position(degrees) > dgrs);
  {

    IntakeLeft.stop();

    IntakeRight.stop();

    vex::this_thread::sleep_for(100);
  }
}

void outTake(double dgrs) {

  IntakeLeft.setStopping(hold);

  IntakeRight.setStopping(hold);

  IntakeLeft.spin(reverse);

  IntakeRight.spin(reverse);

  waitUntil(IntakeLeft.position(degrees) == -dgrs ||
            IntakeLeft.position(degrees) < -dgrs);
  {

    IntakeLeft.stop();

    IntakeRight.stop();

    vex::this_thread::sleep_for(100);
  }
}




void raiseLift(double distance, int vel2) {

  IntakeLeft.setVelocity(vel2, percent);

  IntakeRight.setVelocity(vel2, percent);

  IntakeLeft.spin(forward);

  IntakeRight.spin(forward);

  waitUntil(IntakeRight.position(degrees) >= distance);
  {
    Brain.Screen.drawCircle(500,300,50);
    IntakeLeft.setStopping(hold);
    IntakeRight.setStopping(hold);
    IntakeLeft.stop();

    IntakeRight.stop();

    vex::this_thread::sleep_for(100);
  }
}

void lowerLift(double distance, int vel){
IntakeLeft.setPosition(0,degrees);
IntakeLeft.setVelocity(vel, percent);
IntakeRight.setVelocity(vel, percent);
IntakeLeft.spin(reverse);
IntakeRight.spin(reverse);

waitUntil(IntakeLeft.position(degrees) >= distance);
{
  IntakeLeft.stop();
  IntakeRight.stop();
  vex :: this_thread::sleep_for(100);
}

}
  


void AlignWithRed(){
  int x=0; int y=0; int width=0 ;
  Vision.takeSnapshot(Vision__REDBOX);
  while(true){
    Vision.takeSnapshot(Vision__REDBOX);
    Brain.Screen.clearScreen();
    x=Vision.largestObject.originX;
    y=Vision.largestObject.originY;
    width=Vision.largestObject.width;
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawCircle(x,y,width);
    if(Vision.largestObject.originX>10&&Vision.largestObject.originX<60){
        BRMotor.setVelocity(20,percent);
        FRMotor.setVelocity(20,percent);
        FLMotor.setVelocity(20,percent);
        BLMotor.setVelocity(20,percent);

        BLMotor.spin(forward);
        FLMotor.spin(forward);
        FRMotor.spin(reverse);
        BRMotor.spin(reverse);
        
    }
    else if(Vision.largestObject.originX>170){
        BRMotor.setVelocity(20,percent);
        FRMotor.setVelocity(20,percent);
        FLMotor.setVelocity(20,percent);
        BLMotor.setVelocity(20,percent);
        BRMotor.spin(forward);
        FRMotor.spin(forward);
        FLMotor.spin(reverse);
        BLMotor.spin(reverse);
    }
      
        

        
  }

  vex::this_thread::sleep_for (100);
  
}

void openClaw( int vel)
{
  mClaw.setPosition(0,degrees);
  mClaw.setVelocity(vel,percent);
  mClaw.spinToPosition(150,degrees);

}


void closeClaw()
{
  mClaw.setPosition(80,degrees);
  mClaw.spinToPosition(0,degrees);
  mClaw.setTimeout(5,seconds);
}

int main() {
  vexcodeInit();
  // Initializing Robot Configuration. DO NOT REMOVE!
  //start by facing wall, as close to hoop as possible
  openClaw(100);
  
  Forward(1000,50);
  closeClaw();
  raiseLift(100,80);
  Backwards(1000,40);
  
  //Forward(1100,500);
  //closeClaw
  //raiseLift(100,80);

  /*Left(230,70);
  vex::this_thread::sleep_for(100);
  Forward(1200,100);
  vex::this_thread::sleep_for(100);
  Right(100,70);
  Forward(1000,100);*/
}