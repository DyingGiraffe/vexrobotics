using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern motor BLMotor;
extern motor BRMotor;
extern motor FLMotor;
extern motor FRMotor;
extern motor IntakeLeft;
extern motor IntakeRight;
extern signature Vision12__SIG_1;
extern signature Vision12__SIG_2;
extern signature Vision12__SIG_3;
extern signature Vision12__SIG_4;
extern signature Vision12__SIG_5;
extern signature Vision12__SIG_6;
extern signature Vision12__SIG_7;
extern vision Vision12;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );